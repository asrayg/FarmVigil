# Cow > 2023-09-30 10:28pm
https://universe.roboflow.com/farmvigil-gnng5/cow-wzk0r

Provided by a Roboflow user
License: CC BY 4.0

